import React, { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { Container, Form, Button, Col } from "react-bootstrap";

const EmployeeDetails = () => {
  const location = useLocation();
  const eId = location.state.eId;
  const [employee, setEmployee] = React.useState({});
  const [title, setTitle] = React.useState("");
  const [department, setDepartment] = React.useState("");
  const [currentStatus, setCurrentStatus] = React.useState("");
  const [remainingTime, setRemainingTime] = React.useState({
    days: 0,
    months: 0,
    years: 0,
  });

  const getEmployeeDetails = async () => {
    fetch("/graphql", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        query: `
          query Employee($employeeId: Int) {
            employee(id: $employeeId) {
              CurrentStatus
              DateOfJoining
              Department
              EmployeeType
              FirstName
              id
              Title
              LastName
              Age
            }
          }
        `,
        variables: { employeeId: eId },
      }),
    })
      .then((res) => res.json())
      .then((body) => {
        if (body.data.employee.DateOfJoining) {
          body.data.employee.DateOfJoining = new Date(
            body.data.employee.DateOfJoining
          );
        }
        // set the employee state to the employee object returned from the query
        setEmployee(body.data.employee);
        setTitle(body.data.employee.Title);
        setDepartment(body.data.employee.Department);
        setCurrentStatus(body.data.employee.CurrentStatus);
        calculateRetirement(
          body.data.employee.Age,
          body.data.employee.DateOfJoining
        );
      })
      .catch((error) => {
        console.error("Error fetching employee details:", error);
      });
  };

  // const calculateRemainingTime = (age, dateOfJoining) => {
  //   // Assuming retirement age is 65 for example
  //   console.log('dateOfJoining '+dateOfJoining);
  //   const retirementAge = 65;
  //   const currentYear = new Date();
  //   console.log('currentYear '+currentYear);
  //   const yearsToBeRetired = 65 - age;
  //   console.log('yearsToBeRetired '+yearsToBeRetired);
  //   const time = new Date(currentYear - yearsToBeRetired);

  //   console.log('time '+time);

  //   const retirementYear = currentYear + retirementAge - age;
  //   // const retirementYear = currentYear + retirementAge - employee.Age;
  //   console.log('retirementYear '+retirementYear);
  //   const remainingMilliseconds = new Date().getTime() - dateOfJoining.getTime();
  //   console.log('remainingMilliseconds '+remainingMilliseconds);
  //   const remainingDays = Math.floor(remainingMilliseconds / (1000 * 60 * 60 * 24));
  //   console.log('remainingDays '+remainingDays);
  //   const remainingYears = Math.floor(remainingDays / 365);
  //   console.log('remainingYears '+remainingYears);
  //   const remainingMonths = Math.floor((remainingDays % 365) / 30);
  //   console.log('remainingMonths '+remainingMonths);
  //   console.log('remainingDays%30 '+remainingDays % 30);
  //   setRemainingTime({
  //     years: remainingYears,
  //     months: remainingMonths,
  //     days: remainingDays % 30,

  //   });
  // };

  const calculateRetirement = (ageAtJoining, dateOfJoining) => {
    const retirementAge = 65;
    const currentYear = new Date();
    const dobYear = retirementAge - ageAtJoining;
    const retirementYears = new Date(dateOfJoining);
    retirementYears.setFullYear(retirementYears.getFullYear() + dobYear);
    const timeDifference = retirementYears - currentYear;
    const years = Math.floor(timeDifference / (365 * 24 * 60 * 60 * 1000));
    const months = Math.floor(
      (timeDifference % (365 * 24 * 60 * 60 * 1000)) /
        (30 * 24 * 60 * 60 * 1000)
    );
    const days = Math.floor(
      (timeDifference % (30 * 24 * 60 * 60 * 1000)) / (24 * 60 * 60 * 1000)
    );
    setRemainingTime({ days, months, years });
  };
  useEffect(() => {
    getEmployeeDetails();
  }, []);

  const updateEmployee = async (e) => {
    e.preventDefault();

    const updatedFields = {
      Title: title,
      Department: department,
      CurrentStatus: parseInt(currentStatus),
    };

    try {
      const response = await fetch("/graphql", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          query: `
            mutation UpdateEmployee($id: Int!, $input: EmployeeInput) {
              updateEmployee(id: $id, input: $input) {
                id
                Title
                Department
                CurrentStatus
              }
            }
          `,
          variables: {
            id: eId,
            input: updatedFields,
          },
        }),
      });

      const result = await response.json();
      console.log("Updated Employee:", result.data.updateEmployee);
      if (result.data.updateEmployee) {
        window.alert("Employee successfully updated!");
      } else {
        window.alert("Failed to update employee.");
      }
    } catch (error) {
      console.error("Error updating employee:", error);
    }
  };

  return (
    <Container
      style={{
        boxShadow: "0 4px 8px rgba(0, 0, 0, 0.9)",
        padding: "20px",
        marginTop: "30px",
      }}
    >
      <Form onSubmit={updateEmployee}>
        <h1>Employee Details</h1>
        <Form.Group as={Col} controlId="id">
          <Form.Label>Employee ID:</Form.Label>
          <Form.Control type="text" value={employee.id} disabled />
        </Form.Group>
        <Form.Group as={Col} controlId="fname">
          <Form.Label>First Name:</Form.Label>
          <Form.Control type="text" value={employee.FirstName} disabled />
        </Form.Group>
        <Form.Group as={Col} controlId="lname">
          <Form.Label>Last Name:</Form.Label>
          <Form.Control type="text" value={employee.LastName} disabled />
        </Form.Group>
        <Form.Group as={Col} controlId="age">
          <Form.Label>Age:</Form.Label>
          <Form.Control type="text" value={employee.Age} disabled />
        </Form.Group>
        <Form.Group as={Col} controlId="date">
          <Form.Label>Date of Joining:</Form.Label>
          <Form.Control
            type="text"
            value={
              employee.DateOfJoining != null
                ? employee.DateOfJoining.toDateString()
                : ""
            }
            disabled
          />
        </Form.Group>
        <Form.Group as={Col} controlId="title">
          <Form.Label>Title:</Form.Label>
          <Form.Select value={title} onChange={(e) => setTitle(e.target.value)}>
            <option>Employee</option>
            <option>Manager</option>
            <option>Director</option>
            <option>VP</option>
          </Form.Select>
        </Form.Group>
        <Form.Group as={Col} controlId="dept">
          <Form.Label>Department:</Form.Label>
          <Form.Select
            value={department}
            onChange={(e) => setDepartment(e.target.value)}
          >
            <option>IT</option>
            <option>Marketing</option>
            <option>HR</option>
            <option>Engineering</option>
          </Form.Select>
        </Form.Group>
        <Form.Group as={Col} controlId="empType">
          <Form.Label>Employee Type:</Form.Label>
          <Form.Control type="text" value={employee.EmployeeType} disabled />
        </Form.Group>
        <Form.Group as={Col} controlId="status">
          <Form.Label>Current Status:</Form.Label>
          <Form.Control
            type="number"
            value={currentStatus}
            onChange={(e) => setCurrentStatus(e.target.value)}
          />
        </Form.Group>
        <Form.Group as={Col} controlId="remainingTime">
          <Form.Label>Time to Retirement:</Form.Label>
          <Form.Control
            type="text"
            value={`${remainingTime.years} years, ${remainingTime.months} months, ${remainingTime.days} days`}
            disabled
          />
        </Form.Group>
        <br />
        <Button type="submit" variant="primary">
          Update
        </Button>
      </Form>
    </Container>
  );
};

export default EmployeeDetails;
