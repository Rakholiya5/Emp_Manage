import React, { Component } from "react";
import { Container} from "react-bootstrap";
import { Outlet } from "react-router-dom";
import EmployeeList from "../employee/EmployeeList";

class EmployeeDirectory extends Component {
  constructor() {
    super();
    this.state = {
      employees: [],
      og_employees: [],
    };
  }

  render() {
    return (
      <Container>
      
          <h1 className="text-center text-uppercase" >
            Employee Management System
          </h1>
      
        <Outlet />
        <EmployeeList employees={this.state.employees} />
      </Container>
    );
  }
}

export default EmployeeDirectory;
