import React from "react";
import { Container, Button } from "react-bootstrap";
import { Link } from "react-router-dom";

const NotFound = () => {
  return (
    <Container className="text-center">
      <h1>404</h1>
      <p>Page Not Found</p>
      <Link to="/">
        <Button variant="primary">Go back</Button>
      </Link>
    </Container>
  );
};

export default NotFound;
