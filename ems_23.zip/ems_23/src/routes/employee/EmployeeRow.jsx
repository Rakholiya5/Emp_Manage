import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "react-bootstrap";

const EmployeeRow = ({ employee, onDeleteClick }) => {
  const navigate = useNavigate();

  const deleteEmployee = () => {
    onDeleteClick(employee.id);
  };

  return (
    <tr>
      <td>{employee.id}</td>
      <td>{employee.FirstName}</td>
      <td>{employee.LastName}</td>
      <td>{employee.Age}</td>
      <td>
        {employee.DateOfJoining != null
          ? employee.DateOfJoining.toDateString()
          : ""}
      </td>
      <td>{employee.Title}</td>
      <td>{employee.Department}</td>
      <td>{employee.EmployeeType}</td>
      <td>{employee.CurrentStatus}</td>
      <td>
        {/* navigate to EmployeeDetails page with selected id */}
        <Button
          variant="primary"
          onClick={() => {
            navigate(`/employee/${employee.id}`, {
              replace: false,
              state: { eId: employee.id },
            });
          }}
        >
          View
        </Button>
      </td>
      <td>
        <Button variant="danger" onClick={deleteEmployee}>
          Delete
        </Button>
      </td>
    </tr>
  );
};

export default EmployeeRow;
