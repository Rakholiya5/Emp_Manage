import React from "react";
import { Table, Button } from "react-bootstrap";
import EmployeeRow from "./EmployeeRow";

const EmployeeTable = ({ employees, onDeleteClick }) => {
  const employeeRows = employees.map((employee) => (
    <EmployeeRow
      key={employee.id}
      employee={employee}
      onDeleteClick={onDeleteClick}
    />
  ));

  return (
    <Table striped bordered>
      <thead>
        <tr className="text-center">
          <th>No.</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Age</th>
          <th>Date of Joining</th>
          <th>Title</th>
          <th>Department</th>
          <th>Employee Type</th>
          <th>Current Status</th>
          <th>View Details</th>
          <th>Delete</th>
        </tr>
      </thead>
      <tbody>{employeeRows}</tbody>
    </Table>
  );
};

export default EmployeeTable;
