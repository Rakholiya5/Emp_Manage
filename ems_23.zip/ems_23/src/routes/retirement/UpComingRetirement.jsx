import React, { useState, useEffect } from "react";
import { Container, Row, Col } from "react-bootstrap";
import EmployeeFilter from "../../components/EmployeeFilter";
import EmployeeTable from "../employee/EmployeeTable";

const UpComingRetirement = () => {
  const [retiringEmployees, setRetiringEmployees] = useState([]);
  const [ogRetiringEmployees, setOgRetiringEmployees] = useState([]);

  const fetchEmployees = () => {
    fetch("/graphql", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        query: `
          query {
            employees {
              id
              FirstName
              LastName
              Age
              DateOfJoining
              Title
              Department
              EmployeeType
              CurrentStatus
            }
          }
        `,
      }),
    })
      .then((res) => res.json())
      .then((body) => {
        body.data.employees.forEach((employee) => {
          employee.DateOfJoining = new Date(employee.DateOfJoining);
        });
        getRetiringEmployees(body.data.employees);
      });
  };

  const calculateRetirement = (employee) => {
    const retirementAge = 65;
    const currentYear = new Date();
    const dobYear = retirementAge - employee.Age;
    const retirementYears = new Date(employee.DateOfJoining);
    retirementYears.setFullYear(retirementYears.getFullYear() + dobYear);
    const timeDifference = retirementYears - currentYear;
    const years = Math.floor(timeDifference / (365 * 24 * 60 * 60 * 1000));
    const months = Math.floor(
      (timeDifference % (365 * 24 * 60 * 60 * 1000)) /
        (30 * 24 * 60 * 60 * 1000)
    );
    // console.log(employee.FirstName, "--", years, "years_", months, "months_");
    return years === 0 && months <= 6;
  };

  const getRetiringEmployees = (employeeList) => {
    const upComingRetirements = employeeList.filter((employee) => {
      return calculateRetirement(employee);
    });
    setRetiringEmployees(upComingRetirements);
    setOgRetiringEmployees(upComingRetirements);
  };

  const filterEmployees = (employeeType) => {
    if (employeeType === "All" || employeeType === "") {
      setRetiringEmployees(ogRetiringEmployees);
      return;
    }
    const filteredEmployees = ogRetiringEmployees.filter(
      (employee) => employee.EmployeeType === employeeType
    );
    setRetiringEmployees(filteredEmployees);
  };

  const deleteEmployee = (employeeId) => {
    const CheckStatus = ogRetiringEmployees.find(
      (employee) => employee.id === employeeId
    );
    if (CheckStatus && CheckStatus.CurrentStatus) {
      alert("CAN'T DELETE EMPLOYEE - STATUS ACTIVE");
      return;
    }
    const query = `
      mutation Mutation($deleteEmployeeId: Int) {
        deleteEmployee(id: $deleteEmployeeId)
      }
    `;
    fetch("/graphql", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        query,
        variables: { deleteEmployeeId: employeeId },
      }),
    })
      .then((res) => res.json())
      .then((body) => {
        if (body.data.deleteEmployee > 0) {
          this.componentDidMount();
          alert("Employee Data deleted successfully!");
        } else {
          console.error("Failed to delete employee");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  return (
    <Container
      style={{
        boxShadow: "0 4px 8px rgba(0, 0, 0, 0.9)",
        padding: "20px",
        marginTop: "30px",
      }}
    >
      <h2 className="text-center">UPCOMING RETIREMENT </h2>
      <Row>
        <Col xs={12}>
          <EmployeeFilter filterEmployees={filterEmployees} />
        </Col>
      </Row>
      <EmployeeTable
        employees={retiringEmployees}
        onDeleteClick={deleteEmployee}
      />
    </Container>
  );
};

export default UpComingRetirement;
