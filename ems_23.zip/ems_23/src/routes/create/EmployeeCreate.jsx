import React, { Component } from "react";
import { Container, Form, Button, Row, Col } from "react-bootstrap";

class EmployeeCreate extends Component {
  constructor(props) {
    super(props);
    this.state = {
      employees: [],
      og_employees: [],
    };
  }

  createEmployee = (employee) => {
    fetch("/graphql", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        query: `mutation Mutation($employee: EmployeeInput) { 
          addEmployee(employee: $employee) {
            id
            FirstName
            LastName
            Age
            DateOfJoining
            Title
            Department
            EmployeeType
            CurrentStatus
          }
        }`,
        variables: { employee },
      }),
    })
      .then((res) => res.json())
      .then((body) => {
        body.data.addEmployee.DateOfJoining = new Date(
          body.data.addEmployee.DateOfJoining
        );
        const { employees } = this.state;
        const newEmployeeArray = [...employees, body.data.addEmployee];
        this.setState({
          employees: newEmployeeArray,
          og_employees: newEmployeeArray,
        });
      });
  };

  handleSubmit = (event) => {
    event.preventDefault();

    const form = event.target;

    if (form.fname.value === "") {
      document.getElementById("fnameerror").textContent =
        "First Name Is Required.";
    }
    if (form.lname.value === "") {
      document.getElementById("lnameerror").textContent =
        "Last Name Is Required.";
    }
    if (form.date.value === "") {
      document.getElementById("dateerror").textContent =
        "Please select date of join";
    }
    if (form.age.value === "") {
      document.getElementById("ageerror").textContent = "Select valid age";
    } else if (form.age.value < 20 || form.age.value > 70) {
      document.getElementById("ageerror").textContent =
        "Age should be between 20 to 70";
    } else {
      this.createEmployee({
        FirstName: form.fname.value,
        LastName: form.lname.value,
        Age: parseInt(form.age.value),
        DateOfJoining: form.date.value,
        Title: form.title.value,
        Department: form.dept.value,
        EmployeeType: form.type.value,
      });

      // Reset form fields
      form.fname.value = "";
      form.lname.value = "";
      form.age.value = "";
      form.date.value = "";
      form.title.value = "";
      form.dept.value = "";
      form.type.value = "";
      // reset error messages
      document.getElementById("fnameerror").textContent = "";
      document.getElementById("lnameerror").textContent = "";
      document.getElementById("ageerror").textContent = "";
      document.getElementById("dateerror").textContent = "";
    }
  };

  render() {
    return (
      <Container id="_addForm">
        <h2 className="text-center text-uppercase">Add Employee Form</h2>
        <Form
          name="newEmployeeForm"
          style={{ padding: 20, boxShadow: "0 4px 8px rgba(0,0,0,0.9)"  }}
          onSubmit={this.handleSubmit}
        >
          <Row className="mb-3">
            <Form.Group as={Col} controlId="fName">
              <Form.Label>First Name:</Form.Label>
              <Form.Control type="text" name="fname" />
              <span style={{ color: "red" }} id="fnameerror"></span>
            </Form.Group>
          </Row>
          <Row className="mb-3">
            <Form.Group as={Col} controlId="lName">
              <Form.Label>Last Name:</Form.Label>
              <Form.Control type="text" name="lname" />
              <span style={{ color: "red" }} id="lnameerror"></span>
            </Form.Group>
          </Row>
          <Row className="mb-3">
            <Form.Group as={Col} controlId="age">
              <Form.Label>Age:</Form.Label>
              <Form.Control type="number" name="age" />
              <span style={{ color: "red" }} id="ageerror"></span>
            </Form.Group>
          </Row>
          <Row className="mb-3">
            <Form.Group as={Col} controlId="date">
              <Form.Label>Date of Joining:</Form.Label>
              <Form.Control type="date" name="date" />
              <span style={{ color: "red" }} id="dateerror"></span>
            </Form.Group>
          </Row>
          <Row className="mb-3">
            <Form.Group as={Col} controlId="title">
              <Form.Label>Title:</Form.Label>
              <Form.Select name="title">
                <option>Employee</option>
                <option>Manager</option>
                <option>Director</option>
                <option>VP</option>
              </Form.Select>
            </Form.Group>
          </Row>
          <Row className="mb-3">
            <Form.Group as={Col} controlId="dept">
              <Form.Label>Department:</Form.Label>
              <Form.Select name="dept">
                <option>IT</option>
                <option>Marketing</option>
                <option>HR</option>
                <option>Engineering</option>
              </Form.Select>
            </Form.Group>
          </Row>
          <Row className="mb-3">
            <Form.Group as={Col} controlId="type">
              <Form.Label>Employee Type:</Form.Label>
              <Form.Select name="type">
                <option>FullTime</option>
                <option>PartTime</option>
                <option>Contract</option>
                <option>Seasonal</option>
              </Form.Select>
            </Form.Group>
          </Row>
          <Row className="mb-3">
            <Button type="submit" variant="primary">
              Add
            </Button>
          </Row>
        </Form>
      </Container>
    );
  }
}

export default EmployeeCreate;
