import { Nav, Navbar as ReactBootstrapNavbar } from 'react-bootstrap';
import { Outlet, Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <div>
      <ReactBootstrapNavbar bg="primary" variant="dark" expand="lg">
        <div className="container-fluid">
          <Link className="navbar-brand" to="/">
            EMS
          </Link>
          <ReactBootstrapNavbar.Toggle aria-controls="navbarNav" />
          <ReactBootstrapNavbar.Collapse id="navbarNav">
            <Nav className="navbar-nav">
              <Nav.Item>
                <Link className="nav-link" to="/" aria-current="page">
                  EmployeeList
                </Link>
              </Nav.Item>
              <Nav.Item>
                <Link className="nav-link" to="/create" aria-current="page">
                  Create Employee
                </Link>
              </Nav.Item>
              <Nav.Item>
                <Link className="nav-link" to="/upcoming" aria-current="page">
                  Upcoming Retirement
                </Link>
              </Nav.Item>
            </Nav>
          </ReactBootstrapNavbar.Collapse>
        </div>
      </ReactBootstrapNavbar>
      <Outlet />
    </div>
  );
};

export default Navbar;
