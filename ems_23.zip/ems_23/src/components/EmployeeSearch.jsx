import React from "react";
import { Row, Form, InputGroup, FormControl, Button } from "react-bootstrap";

const EmployeeSearch = () => {
  return (
    <Row>
      <Form className="mb-3">
        <InputGroup>
          <FormControl
            type="text"
            placeholder="Search Employee"
            className="form-control"
          />
          <Button variant="success" type="button">
            Search
          </Button>
        </InputGroup>
      </Form>
    </Row>
  );
};

export default EmployeeSearch;
