import React, { useState } from "react";
import { InputGroup, FormControl, Button, Dropdown } from "react-bootstrap";

const EmployeeFilter = ({ filterEmployees }) => {
  const [filter, setFilter] = useState("");

  const handleFilterChange = (selectedFilter) => {
    setFilter(selectedFilter);
  };

  const applyFilter = () => {
    filterEmployees(filter);
  };

  return (
    <InputGroup className="mb-3">
      <Dropdown onSelect={handleFilterChange}>
        <Dropdown.Toggle variant="outline-secondary" id="filterDropdown">
          {filter || "Filter By Employee Type"}
        </Dropdown.Toggle>
        <Dropdown.Menu>
          <Dropdown.Item eventKey="All">All</Dropdown.Item>
          <Dropdown.Item eventKey="FullTime">FullTime</Dropdown.Item>
          <Dropdown.Item eventKey="PartTime">PartTime</Dropdown.Item>
          <Dropdown.Item eventKey="Contract">Contract</Dropdown.Item>
          <Dropdown.Item eventKey="Seasonal">Seasonal</Dropdown.Item>
        </Dropdown.Menu>
      </Dropdown>
      {/* <FormControl
        aria-label="Filter by Employee Type"
        aria-describedby="filterDropdown"
        value={filter}
        onChange={(e) => setFilter(e.target.value)}
      /> */}
      <Button variant="outline-primary" onClick={applyFilter}>
        Filter
      </Button>
    </InputGroup>
  );
};

export default EmployeeFilter;
