import EmployeeDirectory from "./components/EmployeeDirectory";
import './App.css';
function App() {
  return /*#__PURE__*/React.createElement("div", {
    className: "App"
  }, /*#__PURE__*/React.createElement(EmployeeDirectory, null));
}
export default App;